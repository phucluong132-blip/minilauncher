# Zalo Lite 0.3.0

Bản này được chuẩn hóa để mở và biên dịch thành APK bằng Android Studio hoặc GitHub Actions.

## Tính năng
- Trang chủ: mở Zalo chính thức hoặc trang Google Play.
- Tab Zalo OA: liên kết tài liệu Zalo Developers và cổng OA.
- Tab Cài đặt: bật/tắt giao diện tối, lưu lựa chọn.
- Giao diện Android Native, không chạy service nền.
- Không thu thập mật khẩu, OTP, cookie hoặc dữ liệu trò chuyện.

## Tương thích
- minSdk 21: Android 5.0 trở lên.
- Java 8 source/target.
- Build với Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17, SDK 35.
- Thiết bị ARM32/ARM64 được Android hỗ trợ; APK được đóng gói theo ABI mặc định của Android Gradle Plugin.

## Tạo APK bằng Android Studio
1. Cài Android Studio và JDK 17.
2. Mở thư mục dự án `ZaloLite-v0.3`.
3. Chờ Gradle Sync hoàn tất.
4. Chọn **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

## Tạo APK bằng terminal
Cần cài Gradle 8.9, Android SDK Platform 35 và Build Tools tương thích:
```bash
gradle assembleDebug
```
Kết quả:
`app/build/outputs/apk/debug/app-debug.apk`

Để tạo APK release:
```bash
gradle assembleRelease
```
Bản release mặc định chưa ký. Hãy cấu hình signing trong Android Studio/Gradle trước khi phát hành.

## Tạo APK tự động bằng GitHub Actions
1. Tạo repository GitHub và tải toàn bộ thư mục dự án lên.
2. Vào **Actions**, chạy workflow **Build Android APK**.
3. Tải artifact `ZaloLite-debug-apk` sau khi workflow hoàn tất.

## Giới hạn tích hợp Zalo
Đây là ứng dụng companion/launcher, không phải ứng dụng thay thế Zalo. API OA chỉ dùng sau khi đăng ký và được cấp quyền; cần backend bảo mật. Không nhúng client secret vào APK. Không có API công khai phù hợp để thay thế toàn bộ tin nhắn cá nhân Zalo.
