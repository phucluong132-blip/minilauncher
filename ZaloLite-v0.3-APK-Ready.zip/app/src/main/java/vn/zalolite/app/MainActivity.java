package vn.zalolite.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Zalo Lite 0.3.0 - lightweight companion/launcher.
 * It does not impersonate Zalo or access private Zalo account data.
 */
public class MainActivity extends Activity {
    private static final String ZALO_PACKAGE = "com.zing.zalo";
    private static final String PREFS = "zl_settings";
    private static final String DARK = "dark_mode";

    private boolean dark;
    private int bg, panel, fg, muted, blue;
    private LinearLayout content;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        dark = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(DARK, false);
        render("home");
    }

    private int dp(float n) {
        return (int)(n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void setColors() {
        if (dark) {
            bg = Color.rgb(18, 22, 29);
            panel = Color.rgb(31, 38, 49);
            fg = Color.rgb(239, 243, 248);
            muted = Color.rgb(173, 184, 198);
            blue = Color.rgb(82, 158, 255);
        } else {
            bg = Color.rgb(245, 248, 252);
            panel = Color.WHITE;
            fg = Color.rgb(30, 42, 58);
            muted = Color.rgb(100, 112, 128);
            blue = Color.rgb(0, 119, 255);
        }
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String title, Runnable action) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private LinearLayout.LayoutParams params(int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(bottom);
        return p;
    }

    private void render(String tab) {
        setColors();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(dp(18), dp(22), dp(18), dp(12));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("Zalo Lite", 27, blue, true);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        header.addView(text("v0.3.0", 12, muted, false));
        root.addView(header, params(3));
        root.addView(text("Trợ lý truy cập Zalo gọn nhẹ", 13, muted, false), params(14));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.addView(navButton("Trang chủ", "home", tab));
        nav.addView(navButton("Zalo OA", "oa", tab));
        nav.addView(navButton("Cài đặt", "settings", tab));
        root.addView(nav, params(12));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(4), 0, dp(12));

        if ("home".equals(tab)) showHome();
        else if ("oa".equals(tab)) showOA();
        else showSettings();

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private Button navButton(String title, String target, String current) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTextColor(target.equals(current) ? blue : muted);
        b.setBackgroundColor(panel);
        b.setMinHeight(dp(42));
        b.setPadding(dp(2), 0, dp(2), 0);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1);
        p.setMargins(dp(2), 0, dp(2), 0);
        b.setLayoutParams(p);
        b.setOnClickListener(v -> render(target));
        return b;
    }

    private void heading(String title, String subtitle) {
        content.addView(text(title, 19, fg, true), params(4));
        content.addView(text(subtitle, 13, muted, false), params(10));
    }

    private void card(String title, String description, String actionTitle, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(13), dp(14), dp(8));
        card.setBackgroundColor(panel);
        card.addView(text(title, 16, fg, true), params(5));
        card.addView(text(description, 13, muted, false), params(7));
        card.addView(button(actionTitle, action), params(2));
        content.addView(card, params(10));
    }

    private void showHome() {
        heading("Xin chào!", "Mở Zalo nhanh, không cần dịch vụ chạy nền.");
        card("Mở Zalo chính thức",
                "Chuyển sang ứng dụng Zalo đang cài trên điện thoại.",
                "Mở Zalo", this::openZalo);
        card("Cài đặt Zalo",
                "Nếu chưa có Zalo, mở trang ứng dụng trên Google Play.",
                "Tìm Zalo trên Google Play",
                () -> openUrl("https://play.google.com/store/apps/details?id=com.zing.zalo"));
        card("Tối ưu máy Android cũ",
                "Ứng dụng dùng giao diện Android Native và không tự chạy nền.",
                "Xem cài đặt", () -> render("settings"));
        content.addView(text(
                "Zalo Lite là ứng dụng đồng hành độc lập. Tài khoản và tin nhắn cá nhân vẫn được xử lý trong Zalo chính thức.",
                12, muted, false), params(8));
    }

    private void showOA() {
        heading("Zalo Official Account", "Kết nối API OA trong phạm vi quyền được Zalo cấp.");
        card("Tài liệu Zalo Developers",
                "Tìm hiểu OAuth, quyền truy cập và API được hỗ trợ.",
                "Mở tài liệu", () -> openUrl("https://developers.zalo.me/"));
        card("Cổng quản trị OA",
                "Mở trang quản lý Official Account chính thức.",
                "Mở Zalo OA", () -> openUrl("https://oa.zalo.me/"));
        content.addView(text(
                "Chưa có kết nối OA thật trong bản này. Muốn dùng dữ liệu OA cần đăng ký ứng dụng, được cấp quyền và triển khai backend bảo mật. API OA không thay thế hộp thư Zalo cá nhân.",
                13, muted, false), params(8));
    }

    private void showSettings() {
        heading("Cài đặt", "Tùy chỉnh giao diện và thông tin ứng dụng.");
        card("Giao diện",
                dark ? "Đang bật chế độ tối." : "Đang bật chế độ sáng.",
                dark ? "Chuyển sang sáng" : "Chuyển sang tối", () -> {
                    dark = !dark;
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                            .putBoolean(DARK, dark).apply();
                    render("settings");
                });
        card("Thông tin phiên bản",
                "Zalo Lite 0.3.0 · minSdk 21 · Java 8.",
                "Mở trang nhà phát triển",
                () -> openUrl("https://developers.zalo.me/"));
        card("Quyền riêng tư",
                "Không yêu cầu mật khẩu, OTP, cookie hay quyền đọc tin nhắn.",
                "Đã hiểu", () -> Toast.makeText(this,
                        "Ứng dụng không truy cập dữ liệu riêng tư Zalo.",
                        Toast.LENGTH_SHORT).show());
    }

    private void openZalo() {
        PackageManager pm = getPackageManager();
        Intent launch = pm.getLaunchIntentForPackage(ZALO_PACKAGE);
        if (launch != null) {
            startActivity(launch);
        } else {
            Toast.makeText(this, "Chưa tìm thấy Zalo trên thiết bị.",
                    Toast.LENGTH_LONG).show();
            openUrl("https://play.google.com/store/apps/details?id=com.zing.zalo");
        }
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "Không thể mở liên kết.", Toast.LENGTH_SHORT).show();
        }
    }
}
