package vn.minilauncher

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs

/**
 * Our own Back / Home / Recents gestures, for Xiaomi phones that drop native gesture
 * navigation as soon as a third-party launcher is the default home.
 *
 * Thin invisible overlay windows sit on the screen edges; a swipe inside one of them becomes
 * a global action. The service never reads what is on screen.
 */
class GestureService : AccessibilityService() {

    companion object {
        const val KEY_BACK = "g_back"
        const val KEY_HOME = "g_home"
        const val KEY_RECENTS = "g_recents"
        const val KEY_KEEP = "g_keep"
        private const val HOLD_MS = 260L
        private const val WRITE_SECURE = "android.permission.WRITE_SECURE_SETTINGS"

        @Volatile
        var running = false
            private set

        fun canWriteSecure(ctx: Context) =
            ctx.checkSelfPermission(WRITE_SECURE) == PackageManager.PERMISSION_GRANTED

        /**
         * HyperOS likes to switch accessibility services off. When WRITE_SECURE_SETTINGS was
         * granted once through adb, switch ours back on (unless the user opted out).
         */
        fun ensureEnabled(ctx: Context) {
            if (running || !canWriteSecure(ctx)) return
            val prefs = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)
            if (!prefs.getBoolean(KEY_KEEP, true)) return
            runCatching {
                val cr = ctx.contentResolver
                val me = ComponentName(ctx, GestureService::class.java).flattenToString()
                val now = Settings.Secure
                    .getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                    .orEmpty()
                if (me !in now.split(':')) {
                    Settings.Secure.putString(
                        cr,
                        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
                        if (now.isEmpty()) me else "$now:$me",
                    )
                }
                Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            }
        }
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val zones = ArrayList<View>()
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == KEY_BACK || key == KEY_HOME || key == KEY_RECENTS) rebuild()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        running = true
        rebuild()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (running) rebuild()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: Intent?): Boolean {
        shutdown()
        // If the system switched us off, ask to be switched back on (needs the adb-granted permission).
        Handler(Looper.getMainLooper()).postDelayed({ ensureEnabled(applicationContext) }, 800)
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    private fun shutdown() {
        running = false
        handler.removeCallbacksAndMessages(null)
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        clearZones()
    }

    private fun clearZones() {
        zones.forEach { runCatching { wm.removeView(it) } }
        zones.clear()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun rebuild() {
        clearZones()
        val dm = DisplayMetrics()
        val displays = getSystemService(DISPLAY_SERVICE) as DisplayManager
        displays.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)

        val bottom = dp(18)
        val side = dp(16)
        val top = (dm.heightPixels * 0.12f).toInt() // leave the top edge to the status bar
        if (prefs.getBoolean(KEY_BACK, true)) {
            val h = dm.heightPixels - top - bottom
            addZone(Gravity.TOP or Gravity.START, side, h, top, EdgeSwipe(1))
            addZone(Gravity.TOP or Gravity.END, side, h, top, EdgeSwipe(-1))
        }
        val home = prefs.getBoolean(KEY_HOME, true)
        val recents = prefs.getBoolean(KEY_RECENTS, true)
        if (home || recents) {
            addZone(Gravity.BOTTOM or Gravity.START, dm.widthPixels, bottom, 0, BottomSwipe(home, recents))
        }
    }

    private fun addZone(gravity: Int, width: Int, height: Int, y: Int, listener: View.OnTouchListener) {
        val view = View(this).apply { setOnTouchListener(listener) }
        val params = WindowManager.LayoutParams(
            width,
            height,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            this.gravity = gravity
            this.y = y
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        runCatching {
            wm.addView(view, params)
            zones += view
        }
    }

    /** Back: swipe inwards from the left (dir = 1) or right (dir = -1) edge. */
    private inner class EdgeSwipe(private val dir: Int) : View.OnTouchListener {
        private var sx = 0f
        private var sy = 0f
        private var done = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    done = false
                }
                MotionEvent.ACTION_MOVE -> if (!done) {
                    val dx = (e.rawX - sx) * dir
                    if (dx > dp(40) && dx > abs(e.rawY - sy)) {
                        done = true
                        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                        performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                    }
                }
            }
            return true
        }
    }

    /** Home: swipe up from the bottom edge. Recents: swipe up, then pause. */
    private inner class BottomSwipe(
        private val home: Boolean,
        private val recents: Boolean,
    ) : View.OnTouchListener {
        private var sx = 0f
        private var sy = 0f
        private var ax = 0f
        private var ay = 0f
        private var reached = false
        private var fired = false
        private var lastView: View? = null

        private val hold = Runnable {
            if (reached && !fired) {
                fired = true
                lastView?.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
            }
        }

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            lastView = v
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    reached = false
                    fired = false
                    handler.removeCallbacks(hold)
                }
                MotionEvent.ACTION_MOVE -> if (!fired) {
                    val up = sy - e.rawY
                    if (!reached) {
                        if (up > dp(64) && abs(e.rawX - sx) < up) {
                            reached = true
                            ax = e.rawX
                            ay = e.rawY
                            if (recents) handler.postDelayed(hold, HOLD_MS)
                        }
                    } else if (abs(e.rawX - ax) > dp(8) || abs(e.rawY - ay) > dp(8)) {
                        // still moving: restart the "hold" timer
                        ax = e.rawX
                        ay = e.rawY
                        handler.removeCallbacks(hold)
                        if (recents) handler.postDelayed(hold, HOLD_MS)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(hold)
                    if (reached && !fired && home) {
                        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                        performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                    }
                }
                MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(hold)
            }
            return true
        }
    }
}
