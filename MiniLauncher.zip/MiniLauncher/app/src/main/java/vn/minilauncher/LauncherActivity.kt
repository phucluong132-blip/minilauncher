package vn.minilauncher

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged
import java.text.Collator
import java.text.Normalizer
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max

private const val MAX_PINS = 6
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

data class App(val label: String, val pkg: String, val cls: String, val folded: String) {
    val key: String get() = "$pkg/$cls"
}

// "Cài đặt" -> "cai dat": lets people search without typing Vietnamese diacritics.
private fun fold(s: String): String =
    Normalizer.normalize(s, Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace('đ', 'd')
        .replace('Đ', 'D')
        .lowercase()

/**
 * Minimal home screen: clock, up to 6 pinned apps, swipe up for a searchable app list.
 *
 * Gesture-navigation friendly: draws edge-to-edge under transparent system bars, never
 * claims touches that start in the system's back/home gesture zones, and reacts to the
 * system Home gesture (onNewIntent) and Back gesture (OnBackPressedCallback).
 */
class LauncherActivity : ComponentActivity() {

    private lateinit var root: FrameLayout
    private lateinit var home: LinearLayout
    private lateinit var pinsBox: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var search: EditText
    private lateinit var list: ListView

    private val appAdapter = AppAdapter()
    private var apps: List<App> = emptyList()
    private var drawerOpen = false

    // Zones owned by the system's back/home gestures; our own swipes ignore them.
    private var edge: Insets = Insets.NONE
    private var downX = 0f
    private var downY = 0f
    private var tracking = false
    private var listAtTop = true

    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }
    private var pinned: List<String>
        get() = prefs.getString("pins", "").orEmpty().split('\n').filter { it.isNotEmpty() }
        set(value) {
            prefs.edit().putString("pins", value.joinToString("\n")).apply()
        }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            loadApps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)
        buildUi()

        // System Back gesture: close the drawer, otherwise do nothing (we are home).
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                closeDrawer()
            }
        })
        // System Home gesture / button while we are already home.
        addOnNewIntentListener { closeDrawer() }

        registerReceiver(packageReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        })
        loadApps()
    }

    override fun onResume() {
        super.onResume()
        GestureService.ensureEnabled(this)
        if (apps.isNotEmpty()) refreshPins()
    }

    override fun onStop() {
        super.onStop()
        closeDrawer(animate = false)
    }

    override fun onDestroy() {
        unregisterReceiver(packageReceiver)
        super.onDestroy()
    }

    // ---------- UI ----------

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.argb(115, 0, 0, 0)) }

        val clock = TextClock(this).apply {
            format12Hour = "h:mm"
            format24Hour = "HH:mm"
            textSize = 72f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            includeFontPadding = false
            setOnClickListener {
                runCatching { startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS)) }
            }
            setOnLongClickListener {
                showGestureSettings()
                true
            }
        }
        val datePattern = DateFormat.getBestDateTimePattern(Locale.getDefault(), "EEEEdMMMM")
        val date = TextClock(this).apply {
            format12Hour = datePattern
            format24Hour = datePattern
            textSize = 16f
            setTextColor(white(180))
        }
        pinsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        home = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(clock)
            addView(date)
            addView(View(this@LauncherActivity), LinearLayout.LayoutParams(1, 0, 1f))
            addView(pinsBox)
        }

        search = EditText(this).apply {
            hint = getString(R.string.search_hint)
            setHintTextColor(white(110))
            setTextColor(Color.WHITE)
            textSize = 22f
            background = null
            maxLines = 1
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(0, dp(14), 0, dp(14))
            doAfterTextChanged { filter(it?.toString().orEmpty()) }
            setOnEditorActionListener { _, _, _ ->
                appAdapter.items.firstOrNull()?.let { launch(it) }
                true
            }
        }
        list = ListView(this).apply {
            adapter = appAdapter
            divider = null
            selector = ColorDrawable(white(30))
            isVerticalScrollBarEnabled = false
            setOnItemClickListener { _, _, i, _ -> launch(appAdapter.items[i]) }
            setOnItemLongClickListener { _, _, i, _ ->
                showMenu(appAdapter.items[i])
                true
            }
        }
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(242, 0, 0, 0))
            visibility = View.GONE
            isClickable = true // swallow touches so the home screen below stays inert
            addView(search, LinearLayout.LayoutParams(MATCH, WRAP))
            addView(list, LinearLayout.LayoutParams(MATCH, 0, 1f))
        }

        root.addView(home, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(drawer, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val gest = insets.getInsets(WindowInsetsCompat.Type.systemGestures())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            // Some Xiaomi builds report no gesture insets, so keep sane minimums.
            edge = Insets.of(
                max(gest.left, dp(24)), 0, max(gest.right, dp(24)), max(gest.bottom, dp(32))
            )
            val left = max(bars.left, edge.left) + dp(12)
            val right = max(bars.right, edge.right) + dp(12)
            home.setPadding(left, bars.top + dp(32), right, bars.bottom + dp(32))
            drawer.setPadding(left, bars.top + dp(8), right, max(bars.bottom, ime.bottom))
            insets
        }
    }

    private fun refreshPins() {
        pinsBox.removeAllViews()
        val byKey = apps.associateBy { it.key }
        val shown = pinned.mapNotNull { byKey[it] }
        if (shown.isEmpty()) pinsBox.addView(hintLabel(R.string.hint))
        if (!GestureService.running && !prefs.getBoolean("seen_g", false)) {
            pinsBox.addView(hintLabel(R.string.hint_gestures))
        }
        for (app in shown) {
            pinsBox.addView(label(app.label, 30f).apply {
                setOnClickListener { launch(app) }
                setOnLongClickListener {
                    showMenu(app)
                    true
                }
            })
        }
    }

    private fun openDrawer() {
        if (drawerOpen) return
        drawerOpen = true
        drawer.animate().cancel()
        home.animate().cancel()
        drawer.alpha = 0f
        drawer.translationY = dp(48).toFloat()
        drawer.visibility = View.VISIBLE
        drawer.animate().alpha(1f).translationY(0f).setDuration(200).start()
        home.animate().alpha(0f).setDuration(200).start()
    }

    private fun closeDrawer(animate: Boolean = true) {
        if (!drawerOpen) return
        drawerOpen = false
        hideKeyboard()
        search.setText("")
        search.clearFocus()
        list.setSelection(0)
        drawer.animate().cancel()
        home.animate().cancel()
        if (animate) {
            home.animate().alpha(1f).setDuration(160).start()
            drawer.animate().alpha(0f).translationY(dp(48).toFloat()).setDuration(160)
                .withEndAction { if (!drawerOpen) drawer.visibility = View.GONE }
                .start()
        } else {
            home.alpha = 1f
            drawer.visibility = View.GONE
        }
    }

    private fun hideKeyboard() {
        getSystemService(InputMethodManager::class.java)
            .hideSoftInputFromWindow(search.windowToken, 0)
    }

    // ---------- Gestures (our own, never in the system's edge zones) ----------

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x
                downY = ev.y
                listAtTop = !list.canScrollVertically(-1)
                tracking = ev.x > edge.left &&
                    ev.x < root.width - edge.right &&
                    ev.y < root.height - edge.bottom
            }
            // The system takes over for back/home gestures: it sends us CANCEL.
            MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_CANCEL -> tracking = false
            MotionEvent.ACTION_UP -> if (tracking) {
                tracking = false
                onSwipe(ev.x - downX, ev.y - downY)
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun onSwipe(dx: Float, dy: Float) {
        if (abs(dy) < dp(96) || abs(dy) < abs(dx) * 1.5f) return
        if (drawerOpen) {
            if (dy > 0 && listAtTop) closeDrawer()
        } else if (dy < 0) {
            openDrawer()
        } else {
            expandShade()
        }
    }

    @SuppressLint("WrongConstant", "PrivateApi")
    private fun expandShade() {
        runCatching {
            Class.forName("android.app.StatusBarManager")
                .getMethod("expandNotificationsPanel")
                .invoke(getSystemService("statusbar"))
        }
    }

    // ---------- Apps ----------

    @Suppress("DEPRECATION")
    private fun loadApps() {
        thread {
            val pm = packageManager
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val collator = Collator.getInstance()
            val found = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    val name = it.loadLabel(pm).toString()
                    App(name, it.activityInfo.packageName, it.activityInfo.name, fold(name))
                }
                .sortedWith(Comparator { a, b -> collator.compare(a.label, b.label) })
            runOnUiThread {
                apps = found
                filter(search.text.toString())
                refreshPins()
            }
        }
    }

    private fun filter(query: String) {
        val q = fold(query.trim())
        appAdapter.items =
            if (q.isEmpty()) apps
            else apps.filter { it.folded.contains(q) }.sortedByDescending { it.folded.startsWith(q) }
        appAdapter.notifyDataSetChanged()
    }

    private fun launch(app: App) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(app.pkg, app.cls)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        runCatching { startActivity(intent) }.onFailure { loadApps() }
    }

    private fun showMenu(app: App) {
        val isPinned = app.key in pinned
        val labels = arrayOf(
            getString(if (isPinned) R.string.unpin else R.string.pin),
            getString(R.string.app_info),
            getString(R.string.uninstall),
        )
        AlertDialog.Builder(this).setTitle(app.label).setItems(labels) { _, which ->
            when (which) {
                0 -> {
                    if (isPinned) {
                        pinned = pinned - app.key
                    } else if (pinned.size >= MAX_PINS) {
                        Toast.makeText(this, R.string.max_pins, Toast.LENGTH_SHORT).show()
                    } else {
                        pinned = pinned + app.key
                    }
                    refreshPins()
                }
                1 -> runCatching {
                    startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                    )
                }
                2 -> runCatching {
                    startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
                }
                else -> Unit
            }
        }.show()
    }

    private fun showGestureSettings() {
        prefs.edit().putBoolean("seen_g", true).apply()
        val builder = AlertDialog.Builder(this)
        val ctx = builder.context // themed like the dialog, so text stays readable
        val running = GestureService.running
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
        }
        box.addView(TextView(ctx).apply {
            setText(if (running) R.string.service_on else R.string.service_off)
            setPadding(0, 0, 0, dp(8))
        })
        val options = buildList<Pair<String, Int>> {
            add(GestureService.KEY_BACK to R.string.g_back)
            add(GestureService.KEY_HOME to R.string.g_home)
            add(GestureService.KEY_RECENTS to R.string.g_recents)
            if (GestureService.canWriteSecure(this@LauncherActivity)) {
                add(GestureService.KEY_KEEP to R.string.g_keep)
            }
        }
        for ((key, res) in options) {
            box.addView(CheckBox(ctx).apply {
                setText(res)
                isChecked = prefs.getBoolean(key, true)
                setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply() }
            })
        }
        builder.setTitle(R.string.gestures_title)
            .setView(box)
            .setPositiveButton(android.R.string.ok, null)
        if (!running) {
            builder.setNeutralButton(R.string.enable_service) { _, _ ->
                runCatching { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            }
        }
        builder.show()
    }

    // ---------- Helpers ----------

    private fun hintLabel(res: Int) = label(getString(res), 15f, white(150))

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun white(alpha: Int) = Color.argb(alpha, 255, 255, 255)

    private fun label(text: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        setPadding(0, dp(10), 0, dp(10))
    }

    private inner class AppAdapter : BaseAdapter() {
        var items: List<App> = emptyList()

        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? TextView) ?: label("", 24f).apply { setPadding(0, dp(12), 0, dp(12)) }
            row.text = items[position].label
            return row
        }
    }
}
