# Mini Launcher

Launcher tối giản cho Xiaomi / HyperOS, có sẵn cử chỉ điều hướng riêng (Back, Home, Recents).

## Tính năng
- Đồng hồ, tối đa 6 app ghim, vuốt lên mở danh sách app (tìm không cần gõ dấu), vuốt xuống mở thông báo.
- Nhấn giữ app: ghim / thông tin / gỡ cài đặt. Nhấn giữ đồng hồ: cài cử chỉ.
- Cử chỉ riêng: vuốt từ mép trái/phải vào = Back; vuốt lên từ mép dưới = Home; vuốt lên từ mép dưới rồi giữ = Recents.

## Build APK
- Android Studio: File > Open (chọn thư mục này) > Build > Build APK(s). Nếu Studio gợi ý nâng cấp plugin Gradle, cứ đồng ý.
- Hoặc đẩy cả thư mục lên GitHub (kéo thả thư mục trên máy tính), vào tab Actions > "Build APK" > tải artifact `MiniLauncher-debug-apk`.

## Cài đặt trên HyperOS
HyperOS gắn cử chỉ gốc vào launcher hệ thống nên launcher khác bị đưa về 3 nút. Launcher này mang theo cử chỉ riêng.

1. Cài APK, đặt Mini Launcher làm launcher mặc định.
2. Bật dịch vụ cử chỉ (làm TRƯỚC khi ẩn thanh 3 nút):
   - Cách chắc nhất, cần máy tính 1 lần: bật Gỡ lỗi USB, chạy
     `adb shell pm grant vn.minilauncher android.permission.WRITE_SECURE_SETTINGS`
     (nếu báo lỗi quyền, bật thêm "Gỡ lỗi USB (Cài đặt bảo mật)"), rồi mở lại launcher. Dịch vụ tự bật và tự bật lại khi hệ thống tắt nó.
   - Không có máy tính: nhấn giữ đồng hồ > Bật dịch vụ > bật "Mini Launcher cử chỉ" trong Trợ năng. Nếu máy chặn "cài đặt bị hạn chế": Cài đặt > Ứng dụng > Mini Launcher > ⋮ > Cho phép cài đặt bị hạn chế.
   - Cả hai cách: bật Tự khởi động và đặt pin "Không hạn chế" cho Mini Launcher, vì HyperOS hay tắt dịch vụ chạy nền.
3. Ẩn thanh 3 nút (mẹo cộng đồng): bật Không gian thứ hai (Second Space), trong đó chọn điều hướng "Cử chỉ", rồi quay lại không gian chính. Có thể xóa không gian thứ hai để cử chỉ gốc không chạy chồng.
4. Nhấn giữ đồng hồ để bật/tắt từng cử chỉ. Nếu một cử chỉ chạy 2 lần (ví dụ Back), tắt nó đi.

## Nếu mất điều hướng
Kéo thanh thông báo xuống > Cài đặt > Màn hình chính > điều hướng hệ thống > chọn "Nút".

## Ghi chú
- Dịch vụ cử chỉ chỉ đặt vài dải trong suốt ở mép màn hình, không đọc nội dung màn hình.
- Chưa được chạy thử trên máy thật; cách ẩn thanh nút dựa trên báo cáo của người dùng HyperOS.
